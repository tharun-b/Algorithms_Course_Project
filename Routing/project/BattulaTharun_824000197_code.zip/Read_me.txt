Name: Tharun Battula
UIN: 824000197
COurse: CPSC 629 Analysis of Algorithms

Instructions for running code:
For Windows
1) You can directly run the "routing.exe" file in command prompt, No command line arguments needed.
2) You can redirect the console output to log file by "routing.exe >output.txt"

For Linux
1) You can compile code by running make commands in terminal. "make clean all"
2) For running output "./routing.out"
3) You can redirect the terminal output to log file by "./routing.out >output.txt"


